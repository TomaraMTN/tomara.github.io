# myOnlineShop
We sell groceries via the internet and offer free delivery to those who live in Matebeleland North Province, Zimbabwe. Any form of payment is accepted i.e Ecocash and RTGS.
